'''
This program uses the Turtle module to create a simple checkers board and displays it on the screen.
It imports a "checkers" function from the "functions" module to draw 
the checkers board. The board consists of a grid of squares representing the checkers game board. 

It sets up the board with the specified pixel size, number of rows, and number of columns, and uses 
a black pen of size 1 to draw the board.

The turtle title is "Activity 2 - Checkers" followed by a beige screen backgroun

To execute the program, run it as the main module, which invokes the main() function.

Usage:
    Run this script to create a checkers board using the Turtle module.

Done By: 
  Group 5 - Dingmukhammed Aidarbek, Hashim Hyder, Mohammed Ramadan and Faizah Mehek
'''

import turtle               # Importing Turtle Module
from functions import checkers  # Importing checker function from functions.py

PIXEL_SIZE = 20  ## Setting Pixel Size
ROWS = 20        ## Settign Row Size
COLUMNS = 20     ## Setting Columns Size

turtle.reset()   # Resetting turle module

pen_color = "black"  ## Setting pen color of turtle
pen_size = 1        ## Setting pen size of turtle

win = turtle.Screen()   # Creating turtle Screen 
win.bgcolor("beige")             ## Setting Background color of screen
win.title("Activity 2 - Checkers")  # Setting Title 

def main():
    turtle.speed(0)  # Setting turtle speed to 0
    turtle.up()    # Turtle pen up 

    checkers(turtle, PIXEL_SIZE, ROWS, COLUMNS, pen_color, pen_size)  # Function call 

    win.exitonclick()   


if __name__ == "__main__":
    main()   # Function call 
