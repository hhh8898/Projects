'''
This program uses the Turtle module to draw multiple strings on a canvas.

It imports a "multiple_strings" function from the "functions" module to draw the strings provided 
by the user on the canvas. The pixel size, pen color, and pen size can be customized 
by the user when prompted for input. 

The strings are obtained through user input, and they are drawn on the canvas.

The program title is "Activity 2 - Drawing" followed by a beige screen background.

To execute the program, run it as the main module, which invokes the main() function.

Usage:
    Run this script to create a canvas where multiple strings are drawn using the Turtle module.
Note:
    The "functions" module should contain the "multiple_strings" function, which is used to draw 
    the strings on the canvas.

Done By:
    Group 5 - Dingmukhammed Aidarbek, Hashim Hyder, Mohammed Ramadan and Faizah Mehek
'''

import turtle            # Importing Turtle Module
from functions import multiple_strings   # Importing multiple_strings function from functions.py

PIXEL_SIZE = 10        ## Setting the pixel size
pen_color = "black"    ## Setting the pen color of the turtle
pen_size = 1           ## Setting the pen size of the turtle
string = input("Enter the string: ")    ## User input to enter the strings for the drawing

win = turtle.Screen()     # Creating a turtle Screen
win.bgcolor("beige")      # Setting background of the Screen
win.title("Activity 2 - Drawing")   # Setting the title 

def main():
    turtle.speed(0)    # Setting the turtle speed
    turtle.up()     # Placing the pen up
    
    multiple_strings(turtle, string, PIXEL_SIZE, pen_color, pen_size)   # Function Call

    win.exitonclick()

if __name__ == "__main__":
    main()       # Function Call
    

