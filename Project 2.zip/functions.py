'''
This module uses the Turtle graphics library to create various drawings based on 
user input or text files.

Functions:
    checkers(turtle, PIXEL_SIZE, ROWS, COLUMNS, pen_color, pen_size): 
        Draws a checkerboard pattern using the given Turtle object: 
        pixel size, number of rows,  number of columns, pen color, and pen size.
    
    alternatingRow(turtle, COLUMNS, PIXEL_SIZE, i): 
        Helper function used by the checkers function to draw a single row of the checkerboard pattern.
    
    draw_pixel(turtle, PIXEL_SIZE, color): 
        Draws a square pixel of the given size and color using the given Turtle object.
    
    color_pixel(a): 
        Converts a string character into a color name. Returns the corresponding color for 
        the given  character code ('0' to '9' and 'A'), or prints an error message if 
        the character code is invalid.

    user_input(turtle, string, PIXEL_SIZE, pen_color, pen_size): 
        Draws a sequence of colored pixels based on the input string, using the given Turtle object:
        pixel size, pen color, and pen size.
    
    multiple_strings(turtle, string, PIXEL_SIZE, pen_color, pen_size): 
        Prompts the user to input multiple strings, and for each string, calls the 
        user_input function to draw the corresponding pixels. Sets the position of the Turtle object
        for each new line of input.
    
    openFile(turtle, string, PIXEL_SIZE, pen_color, pen_size): 
        Reads data from text files and calls the multiple_strings function to draw the corresponding pixels.  
        If the input string is not a valid file path, it calls the multiple_strings 
        function directly with  the input string.

Done By: 
     Group 5 - Dingmukhammed Aidarbek, Hashim Hyder, Mohammed Ramadan and Faizah Mehek
'''
import turtle     # Importing turtle module 

### Functions for Checkers 

def checkers(turtle, PIXEL_SIZE, ROWS, COLUMNS, pen_color,pen_size):
    leftUpCornerX = - COLUMNS/2 * PIXEL_SIZE
    leftUpCornerY = ROWS/2 * PIXEL_SIZE
    turtle.goto(leftUpCornerX, leftUpCornerY)   # Setting the turtle position 
    turtle.color(pen_color)    ## Setting pen color of turtle 
    turtle.pensize(pen_size)   ## Setting pen size of turtle
    turtle.setheading(0)      # Setting the face of the turtle to right side
    nextLineX = leftUpCornerX
    nextLineY = leftUpCornerY
    turtle.down()              # Placing turtle pen down to begin drawing
    for i in range (ROWS):
        turtle.down()          # Placing turtle pen down to begin drawing
        alternatingRow(turtle,COLUMNS,PIXEL_SIZE, i)
        turtle.up()            # Placing turtle pen up
        nextLineY = nextLineY - PIXEL_SIZE
        turtle.goto(nextLineX, nextLineY)  # Setting position of the turtle

def alternatingRow(turtle, COLUMNS, PIXEL_SIZE, i):
    checkers_color = i
    for j in range (COLUMNS):
        if checkers_color % 2 == 0:
            pixel_color = "red"            ###  Using For loop
        else:                  
            pixel_color = "black"
        turtle.fillcolor(pixel_color)   ## Filling the color of the pixel
        turtle.begin_fill()
        for l in range (4):
            turtle.fd(PIXEL_SIZE)
            turtle.right(90)            ### Drawing a Square
        turtle.fd(PIXEL_SIZE)    
        turtle.end_fill()        
        checkers_color += 1

### Functions for the Drawing 

def draw_pixel(turtle, PIXEL_SIZE, color):    # Function for drawing the square
    turtle.down()             # Placing pen down
    turtle.fillcolor(color)   
    turtle.begin_fill()     
    for g in range(4):
        turtle.fd(PIXEL_SIZE)   ### Using For loop
        turtle.right(90)
    turtle.fd(PIXEL_SIZE)
    turtle.end_fill()
    turtle.up()      # Placing the pen up 

def color_pixel(a):          # Function for setting colors to specified variables
    if a == '0':
        return "black"
    elif a == '1':
        return "white"
    elif a == '2':
        return "red"
    elif a == '3':
        return "yellow"
    elif a == '4':
        return "orange"
    elif a == '5':
        return "green"                     
    elif a == '6':                     
        return "yellowgreen"
    elif a == '7':
        return "sienna"
    elif a == '8':
        return "tan"
    elif a == '9':
        return "gray"
    elif a == 'A':
        return "darkgray"
    else:
        print("Invalid Color (False String Code)") # If user input is something else then the above terms
        return False

def user_input(turtle, string, PIXEL_SIZE, pen_color, pen_size): # Function to fill colors 
    turtle.color(pen_color)    # Setting the pen color of the turtle
    turtle.pensize(pen_size)   # Setting the pen size of the turtle
    for char in string:  
        color_name = color_pixel(char)  # Using the color pixel function to input colors (Function call)
        draw_pixel(turtle, PIXEL_SIZE, color_name)    # Function call to draw a square

def multiple_strings(turtle, string, PIXEL_SIZE, pen_color, pen_size): # Function to set the position
    nextLineX = -(((len(string) + 1) * PIXEL_SIZE) / 2)                  # after 1 row
    nextLineY = PIXEL_SIZE
    turtle.goto(nextLineX, nextLineY)    # Setting the position of the turtle
    while string:     # Using While loop
        user_input(turtle, string, PIXEL_SIZE, pen_color, pen_size)
        string = input("Enter the string: ")    # User input to enter the row string
        nextLineY -= PIXEL_SIZE  
        turtle.goto(nextLineX, nextLineY)   # Setting the position of the turtle

def openFile(turtle, string, PIXEL_SIZE, pen_color, pen_size):  # Function to read txt files 
    file_path = input('File name: ')  

    if string in file_path:
        with open(string, 'r') as file:  ## Opening txt file in read mode (With statement so file closes automatically)
            string_list = file.read().splitlines()
            for line in string_list:
                multiple_strings(turtle, line, PIXEL_SIZE, pen_color, pen_size) ## Function call
    else:
        multiple_strings(turtle, string, PIXEL_SIZE, pen_color, pen_size)  ## Function call

