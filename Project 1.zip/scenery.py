'''
This program utilizes Python Turtle commands to artistically render a scenery featuring a 
table, cake, candle and decorations.

This program relies entirely on user inputs, encompassing aspects ranging from the table's 
dimensions to the layers of the cake. The program is meticulously organized into functions and 
user input loops for structured execution.

The primary objective of the program is to enable users to create a customized scenery that 
includes a table, cake, and decorations by inputting their preferences.

Functions: Creating Table, Creating Cake, Creating Decorations and Creating Candle

User inputs: Length and Height of Table, Color of the Table,
Number of Layers (1-5), Size: Length and Height of Each cake Layer, Color of each cake layer

Title: Activity 1 - Scenery
Done by: Group 1

Group 1 - Dingmukhammed, Hashim Hyder, Faizah Mehek and Qasim Mabrouk
'''

import turtle     
win = turtle.Screen()     # Creating the turtle Screen
win.title("Activity 1 - Scenery")  #Creating a title for this code
turta = turtle.Turtle() # Creating a turtle with the name turta
win.bgcolor('beige')    # Setting the Screen Color

radius = 20

# Functions for the Program:

### Function for Creating the Table
def draw_table(tableLength, tableHeight, tableColor,turtle):
    turtle.goto(0,0) ## Setting Turtle Position
    turtle.down()
    turtle.color(tableColor)
    turtle.fillcolor(tableColor)
    turtle.begin_fill()
    turtle.fd(tableLength/2)
    turtle.right(90)
    turtle.fd(tableHeight*0.1)
    turtle.right(90)
    turtle.fd(tableLength*0.125)
    turtle.left(90)
    turtle.fd(tableHeight*0.9)
    turtle.right(90)
    turtle.fd(tableLength*0.125)
    turtle.right(90)
    turtle.fd(tableHeight*0.9)
    turtle.left(90)
    turtle.fd(tableLength*0.0625)
    turtle.left(90)
    turtle.fd(tableHeight*0.7)
    turtle.right(90)
    turtle.fd(tableLength*0.0625)
    turtle.right(90)
    turtle.fd(tableHeight*0.7)
    turtle.left(90)
    turtle.fd(tableLength*0.25)
    turtle.left(90)
    turtle.fd(tableHeight*0.7)
    turtle.right(90)
    turtle.fd(tableLength*0.0625)
    turtle.right(90)
    turtle.fd(tableHeight*0.7)
    turtle.left(90)
    turtle.fd(tableLength*0.0625)
    turtle.left(90)
    turtle.fd(tableHeight*0.9)
    turtle.right(90)
    turtle.fd(tableLength*0.125)
    turtle.right(90)
    turtle.fd(tableHeight*0.9)
    turtle.left(90)
    turtle.fd(tableLength*0.125)
    turtle.right(90)
    turtle.fd(tableHeight*0.1)
    turtle.right(90)
    turtle.fd(tableLength/2)
    turtle.end_fill()
    turtle.up()

### Function for creating the cake layers    

def draw_layer(layerLength, layerHeight, layerColor, turtle):
    turtle.left(90)
    turtle.up()
    turtle.color(layerColor)
    turtle.fillcolor(layerColor)
    turtle.fd(layerHeight+1)
    turtle.down()
    turtle.begin_fill()
    turtle.right(90)
    turtle.fd(layerLength/2)
    turtle.right(90)
    turtle.fd(layerHeight)
    turtle.right(90)
    turtle.fd(layerLength)
    turtle.right(90)
    turtle.fd(layerHeight)
    turtle.right(90)
    turtle.fd(layerLength/2)
    turtle.end_fill()
    turtle.up()

### Function for creating the candles

def draw_candle(radius, turtle):
    turtle.down()
    turtle.color('red')
    turtle.fillcolor('red')
    turtle.begin_fill()
    turtle.circle(radius)
    turtle.end_fill()
    turtle.up()

### Functions for creating the decorations

def draw_decoration(layerLength,layerHeight,turtle):
    turtle.down()
    radius = layerLength / 20
    turtle.color('white')
    turtle.fillcolor('white')
    turtle.begin_fill()
    turtle.fd(layerLength/2 + 2)
    turtle.right(90)
    turtle.fd(layerHeight/4)
    turtle.right(90)
    turtle.fd(2)

    x = 0
    while x != 5:
        turtle.setheading(90)
        turtle.circle(radius,-180)
        turtle.setheading(90)
        turtle.circle(radius,180)
        x+=1
    turtle.setheading(180)
    turtle.fd(2)
    turtle.right(90)
    turtle.fd(layerHeight/4)
    turtle.right(90)
    turtle.fd(layerLength/2 + 2)
    turtle.end_fill()
    turtle.up()


# Functions for Creating items ends

turta._tracer(False)  ## Creating the whole image at once with turta object without moving

## User inputs for the Table Length 
while True:
    tableLength = turtle.numinput('Table length', 'Please enter the length of the table between 100 and 500:')
    if 100 <= tableLength <= 500:
        break
    else:
        print('Try again')

## User inputs for the Table Height
while True:
    tableHeight = turtle.numinput('Table height', 'Please enter the height of the table between 100 and 300:')
    if 100 <= tableHeight <= 300:
        break
    else:
        print('Try again')

## User input for the Table Color
tableColor = turtle.textinput("Table color", 'Please enter the color of the table:')
draw_table(tableLength, tableHeight, tableColor, turta)
i = 0

## User input for the number of cake layers

while True:
    layerNumber = turtle.numinput("Number of layers", 'Please enter the number of cake layers between 1 and 5:')
    if 1 <= layerNumber <= 5:
        break
    else:
        print('Try again')


## User input for entering the cake layer length

while i != layerNumber:
    while True:
        layerLength = turtle.numinput('Layer length', f'Please enter the length of the layer between 100 and {int(tableLength)}:')
        if 100 <= layerLength <= tableLength:
            break
        else:
            print('Try again')

## User input for entering the cake layer height


    while True:
        layerHeight = turtle.numinput('Layer height', 'Please enter the height of the layer between 20 and 100:')
        if 20 <= layerHeight <= 100:
            break
        else:
            print('Try again')

## User input for entering the cake layer color


    layerColor = turtle.textinput("Layer color", 'Please enter the color of the cake layer:')
    draw_layer(layerLength, layerHeight, layerColor, turta)
    i += 1


draw_decoration(layerLength,layerHeight,turta) # Function call for decorations
draw_candle(radius,turta)  # Function call for candle
win.exitonclick() # Displaying the object


